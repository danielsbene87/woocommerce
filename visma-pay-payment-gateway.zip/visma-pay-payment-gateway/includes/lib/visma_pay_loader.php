<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname(__FILE__) . '/Visma/VismaPay.php';
require_once dirname(__FILE__) . '/Visma/VismaPayConnector.php';
require_once dirname(__FILE__) . '/Visma/VismaPayWPConnector.php';
require_once dirname(__FILE__) . '/Visma/VismaPayException.php';
